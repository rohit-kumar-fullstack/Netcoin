import LoginMainPage from '../features/login/main'
import React from 'react'

export default function LoginPage() {
  return (
    <div>
      <LoginMainPage />
    </div>
  )
}
